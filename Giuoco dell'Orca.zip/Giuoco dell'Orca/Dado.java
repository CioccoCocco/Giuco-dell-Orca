import java.util.Random;

class Dado  {
    Random random = new Random();
    int facce;
    
    public Dado( int facce )    {
        this.facce = facce;
    }
    
    public int lancia()
    {
        return random.nextInt(facce) + 1;
    }
}