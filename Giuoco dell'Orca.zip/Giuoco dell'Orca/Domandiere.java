import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Domandiere
{
    private Domanda[] domande;
    private int numDomande = 0;

    public Domandiere( ) throws IOException, FileNotFoundException  {
        this.domande = new Domanda[30];
        
        BufferedReader reader = new BufferedReader(new FileReader("File\\domande.txt"));
        
        String domanda, risposta;
        int corretta;
        Difficoltà diff;
        while( true )  {
            domanda = reader.readLine();
            if( domanda == null )   
                break;
            risposta = "";
            for( int i = 0; i < 4; i++ )    {
                risposta += reader.readLine() + "\n\t";
            }
            corretta = (int)(reader.read() - (int)('0'));
            diff = Difficoltà.getDifficoltà( (int)(reader.read() - (int)('0')) );
            addDomanda( new Domanda( domanda, risposta, diff, corretta, numDomande ) );
            reader.readLine();  //completa lettura riga per evitare intralci
        }
    }
    
    public Domanda domandaRandom( )  {
        int i;
        i = (int)(Math.random() * numDomande);
        return domande[i];
    }
    
    public void addDomanda( Domanda newDomanda )   {
        if( numDomande < domande.length )  {
            domande[numDomande] = newDomanda;
            numDomande++;
        } else {
            System.err.println("Troppe domande inserite");
        }
    }
}