import java.io.IOException;

public class Main   {
    public static void main( String[] args ) throws IOException    {
        GiuocoDellOrca giochiamo = new GiuocoDellOrca();
        do{}while( !giochiamo.svolgiTurno() );
        System.out.println("Grazie per aver giocato");
    }
}