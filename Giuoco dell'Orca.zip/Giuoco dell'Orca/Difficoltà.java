public enum Difficoltà  {
    FACILE (1), 
    MEDIO(2), 
    DIFFICILE(3);
    
    private int valore;
    
    Difficoltà( int val )    {
        this.valore = val;
    }
    
    public static Difficoltà getDifficoltà( int val )    {
        if( val == 1 )  {
            return FACILE;
        } else if ( val == 2 )  {
            return MEDIO;
        } else {
            return DIFFICILE;
        }
    }
}
